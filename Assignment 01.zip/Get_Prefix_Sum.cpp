#include<bits/stdc++.h>
using namespace std;

int main(){
    int N;
    cin>>N;

    vector<int>V(N);

    for(int i=0;i<N;i++){
        cin>>V[i];
    }
    
    vector<long long int> prefix_sum(N);
    prefix_sum[0]=V[0];

    for(int i=1;i<N;i++){
        prefix_sum[i]=prefix_sum[i-1]+V[i];
    }

    reverse(prefix_sum.begin(), prefix_sum.end());
    
    for(int i=0;i<N;i++){
        cout<<prefix_sum[i]<<" ";
    }

   
    return 0;
}