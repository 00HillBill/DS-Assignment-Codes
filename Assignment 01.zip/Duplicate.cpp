#include<bits/stdc++.h>
using namespace std;

int main(){
    int N, flag=0;
    cin>>N;

    int arr[N];
    for(int i=0;i<N;i++){
        cin>>arr[i];
    }

    
    sort(arr, arr+N);

    for(int i=1;i<N;i++){
        if(arr[i]==arr[i-1]){
            flag++;            
            break;
        }
    }

    if(flag==1){
        cout<<"YES"<<endl;
    }
    else
    cout<<"NO"<<endl;
    

    return 0;
}