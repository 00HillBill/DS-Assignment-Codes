#include<bits/stdc++.h>
using namespace std;

int main(){
    int N, M, pos;

    cin>>N;
    vector <int> original(N);
    for(int i=0;i<N;i++){
        cin>>original[i];
    }

    cin>>M;
    vector <int> newArr(M);
    for(int i=0;i<M;i++){
        cin>>newArr[i];
    }
    cin>>pos;

    original.insert(original.begin()+pos, newArr.begin(), newArr.end());

    for(auto x: original){
        cout<<x<<" ";
    }
    

    return 0;
}